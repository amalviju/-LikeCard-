<?php

function when_order_completed($order_id)
{
    $order = wc_get_order($order_id);

    $order->update_meta_data('_marked_as_processing_like4card_plugin', 1);

    $order_details = get_like4card_orders_details($order_id);

    if ($order_details) {

        file_log("Order #{$order_id} has been already processed", [
            'order_id' => $order_id
        ]);

        $order->add_order_note("Order has been already marked as processed, so it won't be reprocessed again.");

        return;
    }

    $like4card_products_details = get_only_like4card_products($order->get_items());

    if ($like4card_products_details['total_quantity_for_all_like4card_products'] == 0) return;

    if ($like4card_products_details['total_quantity_for_all_like4card_products'] > 5) {

        file_log("Order #{$order_id} has been automatically rejected/refunded due to exceeding the maximum purchase quantity, which is 5.", [
            'order_id' => $order_id
        ]);

        $order->add_order_note('Automatically rejected/refunded due to exceeding the maximum purchase quantity, which is 5.');

        $order->update_status('refunded');

        return;
    }


    $total_price = $order->get_total();

    if ($total_price == 0) {

        file_log("Order #{$order_id} total must be greater than 0.", [
            'order_id' => $order_id
        ]);

        AdminNotice::displayError('Order total must be greater than 0.');

        $order->add_order_note('Order total must be greater than 0.');

        $order->update_status('failed');

        return;
    }

    $result = process_order($order, $like4card_products_details['like4card_products']);

    if (!$result) return;

    if ($result->response == 1) return;

    handle_create_order_error($result, $order);

    $order->update_status('processing');
}

add_action('woocommerce_order_status_completed', 'when_order_completed', 1, 1);

function should_be_executed($order, $order_id)
{
    return true;
}

<?php

function decrypt_serial($encrypted_txt)
{
    $secret_key = get_option('like4card_secret_key');
    $secret_iv = get_option('like4card_secret_vi');
    $encrypt_method = 'AES-256-CBC';
    $key = hash('sha256', $secret_key);

    //iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning          
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    $result = openssl_decrypt(base64_decode($encrypted_txt), $encrypt_method, $key, 0, $iv);

    return $result;
}

<?php

// Add Serial Code and Serial Number to Order page
function show_card_info_for_customer_in_order_details_page($item_id, $item, $order)
{
    $like4card_product_id = check_if_has_like4card_product_id_meta($item->get_product_id());

    if (!$like4card_product_id) return;

    $cards_details = get_like4card_orders_details($order->get_id(), $like4card_product_id);

    if (empty($cards_details)) return;
?>
    <ul>
        <?php
        foreach ($cards_details as $card_details) {
        ?>
            <li>
                <div class="serial-code">
                    <strong> <?= __('Serial Code') ?> </strong> <?= esc_html(decrypt_serial($card_details->serial_code)); ?>
                </div>

                <?php
                if (!$card_details->serial_number) continue;
                ?>

                <div class="serial-number">
                    <strong> <?= __('Serial Number') ?> </strong> <?= esc_html($card_details->serial_number); ?>
                </div>
            </li>
        <?php
        } ?>
    </ul>
    <?php
}

add_action('woocommerce_order_item_meta_start', 'show_card_info_for_customer_in_order_details_page', 10, 3);



function action_woocommerce_admin_order_item_headers($order)
{
    if (!$order->has_status('completed')) return;

    $should_show_serial_column = false;

    foreach ($order->get_items() as $item) {

        $like4card_product_id = check_if_has_like4card_product_id_meta($item->get_product_id());

        if ($like4card_product_id) $should_show_serial_column = true;
    }

    if ($should_show_serial_column) echo '<th class="line_packing_weight" data-sort="string-ins"> Serial </th>';
}
add_action('woocommerce_admin_order_item_headers', 'action_woocommerce_admin_order_item_headers', 10, 1);


function action_woocommerce_admin_order_item_values($product, $item, $item_id)
{
    if (!($item instanceof WC_Order_Item_Product)) return;

    if (!$item->get_order()->has_status('completed')) return;

    // $like4card_product_id = check_if_has_like4card_product_id_meta($item->get_product_id());
    $like4card_product_id = check_if_has_like4card_product_id_meta($product->id);

    if (!$like4card_product_id) {

    ?>
        <td class="line_packing_weight">

        </td>

    <?php

        return;
    }

    $order_details = get_like4card_orders_details($item->get_order_id(), $like4card_product_id);

    if (!$order_details) {
    ?>
        <td class="line_packing_weight">

        </td>

    <?php

        return;
    }

    ?>
    <td class="line_packing_weight">
        <ul>
            <?php
            foreach ($order_details as $card_details) {
            ?>
                <li>
                    <div class="serial-code">
                        <strong> <?= __('Serial Code') ?> </strong> <?= esc_html(decrypt_serial($card_details->serial_code)); ?>
                    </div>

                    <?php
                    if (!$card_details->serial_number) continue;
                    ?>

                    <div class="serial-number">
                        <strong> <?= __('Serial Number') ?> </strong> <?= esc_html($card_details->serial_number); ?>
                    </div>
                </li>
            <?php
            } ?>
        </ul>
    </td>
<?php
}
add_action('woocommerce_admin_order_item_values', 'action_woocommerce_admin_order_item_values', 10, 3);

<?php

function remove_cash_on_delivery_payment_when_cart_has_like4card_products($available_gateways)
{
    $customer_cart = WC()->cart;

    if(! $customer_cart) return;

    $like4card_products = get_like4card_products_that_merchant_has_in_his_database();

    $product_ids = array_column($like4card_products, 'id');

    $cart_items = $customer_cart->get_cart();

    foreach ($cart_items as $cart_item) {
    
        if (in_array($cart_item['product_id'], $product_ids)) {
            unset($available_gateways['cod']); // Remove COD payment method
            unset($available_gateways['cheque']); // Remove COD payment method

            
            break;
        }
    }
    return $available_gateways;
}

add_filter('woocommerce_available_payment_gateways', 'remove_cash_on_delivery_payment_when_cart_has_like4card_products');
<?php

function when_payment_approved($order_id)
{
    $order = wc_get_order($order_id);

    $order->update_meta_data('_marked_as_processing_like4card_plugin', 1);

    $order_details = get_like4card_orders_details($order_id);

    if ($order_details) {

        file_log("Order #{$order_id} has been already processed", [
            'order_id' => $order_id
        ]);

        return;
    }

    $like4card_products_details = get_only_like4card_products($order->get_items());

    if ($like4card_products_details['total_quantity_for_all_like4card_products'] == 0) {

        file_log("Order #{$order_id} has been automatically rejected/refunded because the quantity of LikeCard is 0.", [
            'order_id' => $order_id
        ]);

        return;
    }

    if ($like4card_products_details['total_quantity_for_all_like4card_products'] > 5) {

        file_log("Order #{$order_id} has been automatically rejected/refunded due to exceeding the maximum purchase quantity, which is 5.", [
            'order_id' => $order_id
        ]);

        $order->add_order_note('Automatically rejected/refunded due to exceeding the maximum purchase quantity, which is 5.');

        $order->update_status('refunded');

        return;
    }

    $total_price = $order->get_total();

    // Check if the cart total is 0
    if ($total_price == 0) {

        file_log("Order #{$order_id} total must be greater than 0.", [
            'order' => $order_id
        ]);

        // AdminNotice::displayError(__('Order total must be greater than 0.'));
        wc_add_notice(__('Order total must be greater than 0.'), 'error');

        $order->add_order_note('Order total must be greater than 0.');

        // Redirect the user to the cart page
        wp_safe_redirect(wc_get_cart_url());

        return;
    }
    
    $result = process_order($order, $like4card_products_details['like4card_products']);

    if ($result->response == 1) {

        $order->update_meta_data('_marked_as_completed_from_like4card_plugin', 1);

        $order->update_status('completed');

        return;
    }

    handle_create_order_error($result, $order);

    $order->update_status('processing');
}

add_action('woocommerce_payment_complete', 'when_payment_approved', 1, 1);


function should_process_order($order, $order_id)
{
    return true;
}

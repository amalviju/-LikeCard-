<?php

function create_like4card_orders_table()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_orders';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        `woocommerce_order_id` bigint NOT NULL,
        `like4card_order_id` bigint NOT NULL,
        `like4card_product_id` bigint NOT NULL,
        `like4card_bulk_order_id` bigint NOT NULL,
        `serial_number` varchar(255),
        `serial_code` varchar(255) NOT NULL,
        PRIMARY KEY (`like4card_order_id`)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta($sql);

    file_log("creating '$table_name' table ...", [
        // 'sql' => $sql,
        'error' => $wpdb->last_error,
        'is_succeeded' => empty($wpdb->last_error)
    ]);
}

register_activation_hook(PLUGIN_FILE_PATH, 'create_like4card_orders_table');

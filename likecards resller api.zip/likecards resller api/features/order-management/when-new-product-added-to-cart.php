<?php

const MAX_LIKE4CARD_QUANTITY_PER_CART = 5;

add_filter( 'woocommerce_add_to_cart_validation', 'my_custom_cart_validation', 10, 3 );

function my_custom_cart_validation($passed, $product_id, $quantity)
{
    if (!do_we_have_more_than_accepted_number_of_like4card_items_in_customer_cart()) return true;

    wc_add_notice(__('You can only have 5 cards in your cart.'), 'error');

    return false;
}

add_filter( 'woocommerce_add_to_cart_redirect', 'my_custom_add_to_cart_redirect', 10, 1 );

function my_custom_add_to_cart_redirect( $url ) {
  if ( is_shop() && isset( $_REQUEST['action'] ) && $_REQUEST['action'] === 'add-to-cart' ) {
    $cart = WC()->cart;
    $cart_total_quantity = $cart->get_cart_quantity();

    if ( $cart_total_quantity > 5 ) {
      return get_permalink( wc_get_cart_page_id() ); // Redirect to cart page if limit exceeded (optional)
      // Alternatively, you can remove the return statement to keep the user on the shop page without redirection.
    }
  }

  return $url;
}

// do_action( 'woocommerce_set_cart_cookies',  true );
// add_action('woocommerce_add_to_cart', 'custom_add_to_cart', 10, 6);
// function custom_add_to_cart($cart_id, $product_id, $request_quantity, $variation_id, $variation, $cart_item_data)
// {
//     if (!do_we_have_more_than_accepted_number_of_like4card_items_in_customer_cart()) return;

//     // AdminNotice::displayError('You can only have 5 cards in your cart.');

//     // wc_print_notice("You can only have 5 cards in your cart.", 'error');
//     // wc_print_notices();
//     // return;
// }

function do_we_have_more_than_accepted_number_of_like4card_items_in_customer_cart()
{
    $total_quantity_for_like4card_products = 0;

    foreach (WC()->cart->get_cart() as $item) {

        $like4card_product_id = check_if_has_like4card_product_id_meta($item['product_id']);

        if (!$like4card_product_id) continue;

        $total_quantity_for_like4card_products += $item['quantity'];

        if ($total_quantity_for_like4card_products > MAX_LIKE4CARD_QUANTITY_PER_CART) return true;
    }

    return false;
}

<?php

function return_only_like4card_products($order_items)
{
    $like4card_products = [];

    foreach ($order_items as $item) {

        $like4card_product_id = check_if_has_like4card_product_id_meta($item->get_product_id());

        if (!$like4card_product_id) continue;

        $like4card_products[] = [
            'productId' => $like4card_product_id,
            'quantity' => $item->get_quantity()
        ];
    }

    return $like4card_products;
}

function get_only_like4card_products($order_items)
{
    $like4card_products = [];
    $total_quantity_for_like4card_products = 0;

    foreach ($order_items as $item) {

        $like4card_product_id = check_if_has_like4card_product_id_meta($item->get_product_id());

        if (!$like4card_product_id) continue;

        $like4card_products[] = [
            'productId' => $like4card_product_id,
            'quantity' => $item->get_quantity()
        ];

        $total_quantity_for_like4card_products += $item->get_quantity();
    }

    return [
        'like4card_products' => $like4card_products,
        'total_quantity_for_all_like4card_products' => $total_quantity_for_like4card_products
    ];
}
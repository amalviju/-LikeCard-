<?php

// // wp_like4card_orders
// function get_likecard_order_details($request)
// {
//     $body = $request->get_params();

//     if (!array_key_exists('id', $body)) return new WP_REST_Response([
//         'code' => 'order_does_not_exist',
//         'message' => "Order details doesn't exist.",
//         'data' => [
//             'status' => 404
//         ]
//     ], 404);

//     $order_items = get_like4card_orders_serials($body['id']);

//     if (!$order_items) return new WP_REST_Response([
//         'code' => 'order_does_not_exist',
//         'message' => "Order details doesn't exist.",
//         'data' => [
//             'status' => 404
//         ]
//     ], 404);

//     $orderDetails = [];

//     foreach ($order_items as $card_details) {

//         $orderDetails[] = [
//             'likecard_product_id' => $card_details->like4card_product_id,
//             'serial_code' => decrypt_serial($card_details->serial_code),
//             'serial_number' => $card_details->serial_number
//         ];
//     }

//     return new WP_REST_Response([
//         'id' => $body['id'],
//         'order_details' => $orderDetails
//     ], 200);
// }


// //http://x1x.local/wp-json/likecard/v1/order/1/details
// add_action('rest_api_init', function () {

//     register_rest_route('likecard/v1', '/order/(?P<id>\d+)/details', [
//         'methods' => 'GET',
//         'callback' => 'get_likecard_order_details',
//         'permission_callback' => 'get_item_permissions_check',
//         // 'permission_callback' => function ($request) {

//         //     $user = wp_get_current_user();

//         //     if (empty($user->ID)) return false;

//         //     return is_user_logged_in();
//         // },
//         'args' => array(
//             'id' => array(
//                 'validate_callback' => function ($param, $request, $key) {
//                     return is_numeric($param);
//                 }
//             ),
//         ),
//     ]);
// });

// /**
//  * Check if a given request has access to read an item.
//  *
//  * @param  WP_REST_Request $request Full details about the request.
//  * @return WP_Error|boolean
//  */
// function get_item_permissions_check($request)
// {
//     global $current_user;
//     var_dump($current_user); die;
//     // var_dump($request); die();
//     // require_once '/woocommerce/includes/legacy/api/v1/class-wc-api-authentication.php';
//     // $test = new WC_API_Authentication();
//     // $user = wp_get_current_user();
//     // $test->authenticate($user);

//     // $woocommerce_order_id = $request->get_params()['id'];

//     // $post = get_post((int) $woocommerce_order_id);

//     // var_dump($GLOBALS['user_id']); die();

//     var_dump(wp_get_current_user()); die();

//     // var_dump(wc_rest_check_post_permissions('order', 'read'));
//     // die;

//     if ($post && !wc_rest_check_post_permissions('shop_order', 'read')) {
//         return new WP_Error('woocommerce_rest_cannot_view', __('Sorry, you cannot view this resource.', 'woocommerce-rest-api'), array('status' => rest_authorization_required_code()));
//     }

//     return true;
// }

<?php

function is_auto_complete_activated()
{
    return !!get_option('like4card_auto_complete');
}

function notify_customer($order_number, $customer_email, $like4card_orders)
{
    $email_subject = 'Your order has just been completed!';

    $email_body = "Your order [$order_number] is completed. \n";

    foreach ($like4card_orders as $like4card_order) {

        $card_info = $like4card_order->serials[0];

        $serialCode = decrypt_serial($card_info->serialCode);

        $email_body .= "
        {$like4card_order->productName} information: \n
    
        Serial Code: {$serialCode} \n
        ";

        if ($card_info->serialNumber) $email_body .= "Serial Number: {$card_info->serialNumber} \n";

        $email_body .= '===========================';
    }

    wp_mail($customer_email, $email_subject, $email_body);
}

function get_like4card_orders_details($woocommerce_order_id, $like4card_product_id = null)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_orders';

    $query = "SELECT * 
    FROM $table_name 
    WHERE `woocommerce_order_id` = $woocommerce_order_id ";

    if ($like4card_product_id) {
        $query .= " AND `like4card_product_id` = $like4card_product_id";
    }

    $rows = $wpdb->get_results($query);

    return $rows;
}



function has_been_processed_before($woocommerce_order_id, $like4card_product_id, $woocommerce_order_item_id, $expected_quantity = 1)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_orders';

    $rows = $wpdb->get_results("SELECT *
     FROM $table_name 
     WHERE `woocommerce_order_id` = $woocommerce_order_id 
     AND `woocommerce_order_item_id` = $woocommerce_order_item_id
     AND `like4card_product_id` = $like4card_product_id;
     ");

    $number_of_items = count($rows);

    return $number_of_items == $expected_quantity;
}

function process_order($woocommerce_order, $like4card_products)
{
    $like4card_order = create_bulk_order($woocommerce_order->get_id(), $like4card_products);

    if (!$like4card_order || $like4card_order->response == 0) {

        $woocommerce_order->add_order_note($like4card_order->message);

        failed_request_message_log($like4card_order->message, [
            'order'  => $woocommerce_order->get_id()
        ]);

        return $like4card_order;
    }

    $like4card_order_details = fetch_order_details($like4card_order->bulkOrderId);

    if (!$like4card_order_details || $like4card_order_details->response == 0) {

        $woocommerce_order->add_order_note($like4card_order_details->message);

        failed_request_message_log($like4card_order_details->message, [
            'order'  => $woocommerce_order->get_id(),
            'likecard_bulk_order_id' => $like4card_order->bulkOrderId
        ]);

        return $like4card_order_details;
    }

    store_order_details($woocommerce_order->get_id(), $like4card_order_details->orders);

    // notify_customer($woocommerce_order->get_order_number(), $woocommerce_order->get_billing_email(), $like4card_order_details->orders);

    return $like4card_order;
}

function generate_reference_id($woocommerce_order_id)
{
    return time() . '_order_' . $woocommerce_order_id;
}


function store_order_details($woocommerce_order_id, $like4card_orders)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_orders';


    foreach ($like4card_orders as $like4card_order) {

        //in our case, serials array will have only one item.
        $card_info = $like4card_order->serials[0];

        if (!$card_info) {

            failed_request_message_log("LikeCard didn't return a serial code for {$like4card_order->productName}", [
                'order'  => $woocommerce_order_id,
                'product' => $like4card_order->productId,
                'product_name' => $like4card_order->productName,
                'likecard_bulk_order_id' => $like4card_order->bulkOrderId
            ]);

            continue;
        }

        $wpdb->insert($table_name, [
            'woocommerce_order_id' => $woocommerce_order_id,
            'like4card_order_id' => $like4card_order->orderNumber,
            'like4card_product_id' => $like4card_order->productId,
            'like4card_bulk_order_id' => $like4card_order->bulkOrderId,
            'serial_code' => $card_info->serialCode,
            'serial_number' => $card_info->serialNumber
        ]);
    }
}

function create_order($product_id, $reference_id)
{
    $device_id = get_option('like4card_device_id');
    $security_code = get_option('like4card_security_code');
    $email = get_option('like4card_email');
    $password = get_option('like4card_password');
    $timestamp = time();
    $hash = generate_hash($timestamp);

    return sent_form_data_request('https://taxes.like4app.com/online/create_order',  [
        'deviceId' => $device_id,
        'securityCode' => $security_code,
        'email' => $email,
        'password' => $password,
        'productId' => $product_id,
        'referenceId' => $reference_id,
        'time' => $timestamp,
        'hash' => $hash
    ]);
}

function create_bulk_order($woocommerce_order_id, $products)
{
    $device_id = get_option('like4card_device_id');
    $security_code = get_option('like4card_security_code');
    $email = get_option('like4card_email');
    $password = get_option('like4card_password');
    $timestamp = time();
    $hash = generate_hash($timestamp);
    $referenceId = "{$woocommerce_order_id}_order_{$timestamp}";

    $productsEncodedArray = json_encode($products);

    return sent_form_data_request('https://taxes.like4app.com/online/create_order/bulk',  [
        'deviceId' => $device_id,
        'securityCode' => $security_code,
        'email' => $email,
        'password' => $password,
        'products' => $productsEncodedArray,
        'time' => $timestamp,
        'hash' => $hash,
        'referenceId' => $referenceId
    ]);
}

function fetch_order_details($bulk_order_id)
{
    $device_id = get_option('like4card_device_id');
    $security_code = get_option('like4card_security_code');
    $email = get_option('like4card_email');
    $password = get_option('like4card_password');

    return sent_form_data_request('https://taxes.like4app.com/online/get_bulk_order',  [
        'deviceId' => $device_id,
        'securityCode' => $security_code,
        'email' => $email,
        'password' => $password,
        'bulkOrderId' => $bulk_order_id,
    ]);
}

function generate_hash($time)
{
    $email = get_option('like4card_email');
    $phone_number = get_option('like4card_phone_number');
    $key = get_option('like4card_hash_key');
    return hash('sha256', $time . $email . $phone_number . $key);
}

function get_like4card_orders_serials($woocommerce_order_id)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_orders';

    $query = "SELECT * 
    FROM $table_name 
    WHERE `woocommerce_order_id` = $woocommerce_order_id ";

    $rows = $wpdb->get_results($query);

    return $rows;
}

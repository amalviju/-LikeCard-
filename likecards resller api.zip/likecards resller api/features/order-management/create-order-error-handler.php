<?php

function handle_create_order_error($create_order_result, $order)
{
    if (!$create_order_result) {
        AdminNotice::displayError('unable to connect with LikeCard, please try again later.');
        file_log('unable to connect with LikeCard, please try again later.');
        $order->add_order_note('unable to connect with LikeCard, please try again later.');
        return;
    }

    if ($create_order_result->response == 0 && $create_order_result->message == "No stock for this product") {
        AdminNotice::displayError("We're sorry, but one of the items in your order is temporarily unavailable :'( \n Please remove it from your cart or check back later when it's back in stock.");
        file_log("We're sorry, but one of the items in your order is temporarily unavailable :'( \n Please remove it from your cart or check back later when it's back in stock.");
        $order->add_order_note("We're sorry, but one of the items in your order is temporarily unavailable :'( \n Please remove it from your cart or check back later when it's back in stock.");
        return;
    }

    if ($create_order_result->response == 0 && $create_order_result->errorCode == 'max_products_per_order_reached') {
        AdminNotice::displayError("Wow, you've selected a lot of great items! It looks like you've reached the maximum number of products per order, but don't worry, you can always place another order if you need to.");
        file_log("Wow, you've selected a lot of great items! It looks like you've reached the maximum number of products per order, but don't worry, you can always place another order if you need to.");
        $order->add_order_note("Wow, you've selected a lot of great items! It looks like you've reached the maximum number of products per order, but don't worry, you can always place another order if you need to.");
        return;
    }

    AdminNotice::displayError($create_order_result->message);
    file_log($create_order_result->message);
    $order->add_order_note($create_order_result->message);
}

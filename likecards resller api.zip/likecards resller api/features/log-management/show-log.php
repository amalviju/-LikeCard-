<?php

function get_woocommerce_version()
{
    global $woocommerce;

    return $woocommerce->version;
}

function read_logs()
{
    $path = PLUGIN_DIR_PATH . '/errors.txt';

    $contents = '';

    if (!file_exists($path)) {
        return $contents;
    }

    $f = fopen($path, 'r');

    if ($f === false) return $contents;

    if (filesize($path) > 0)
        $contents = fread($f, filesize($path));

    fclose($f);

    return $contents;
}

function read_failed_request_messages_logs()
{
    $path = PLUGIN_DIR_PATH . '/failed_requests_log.txt';

    $contents = '';

    if (!file_exists($path)) {
        return $contents;
    }

    $f = fopen($path, 'r');

    if ($f === false) return $contents;

    if (filesize($path) > 0)
        $contents = fread($f, filesize($path));

    fclose($f);

    return $contents;
}

function get_logs()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_general_logs';

    $query = "SELECT *
    FROM $table_name
    ORDER BY `date` ASC";

    $logs = $wpdb->get_results($query);

    return $logs;
}

function get_ip_address()
{
    $response = send_get_request('http://ip-api.com/json');

    return $response->query;
}

?>

<h1>
    LikeCard Logs
</h1>

<br>
<br>
<br>

<div style="display: flex; justify-content: space-between; flex-wrap: wrap; width: 80%;">

    <div style="width: 45%;">

        <h3> General Logs </h3>

        <div style="height: 600px; overflow-x: scroll; overflow-y: scroll; background-color: white; padding: 20px; ">

            <?php

            $php_version = phpversion();
            $woocommerce_version = get_woocommerce_version();
            $ipAddress = get_ip_address();

            echo "php version: $php_version";
            echo '<br/>';
            echo '<br/>';
            echo "WooCommerce version: $woocommerce_version";
            echo '<br/>';
            echo '<br/>';
            echo "IPv4: $ipAddress";
            echo '<br/>';
            echo '<br/>';
            echo read_logs();
            ?>
        </div>
    </div>

    <div style="width: 45%;">

        <h3> Failed Requests' Logs </h3>

        <div style="height: 600px; overflow-x: scroll; overflow-y: scroll; background-color: white; padding: 20px;">

            <?php

            echo '<br/>';
            echo '<br/>';
            echo read_failed_request_messages_logs();
            ?>
        </div>
    </div>
</div>
<br>
<br>
<button type="button" class="wp-core-ui button wp-core-ui button-primary wp-core-ui button-secondary health-check-button" onclick="downloadLogZipFile(event)"> Download log </button>
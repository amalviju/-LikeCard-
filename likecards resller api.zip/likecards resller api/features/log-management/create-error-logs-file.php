<?php

function create_error_logs_file()
{
    $path = PLUGIN_DIR_PATH . '/errors.txt';
    $file = fopen($path, "a");

    fwrite($file, "<br/> \n");

    fclose($file);
}

register_activation_hook(PLUGIN_FILE_PATH, 'create_error_logs_file');


function create_failed_request_messages_logs_file()
{
    $path = PLUGIN_DIR_PATH . '/failed_requests_log.txt';
    $file = fopen($path, "a");

    fwrite($file, "<br/> \n");

    fclose($file);
}

register_activation_hook(PLUGIN_FILE_PATH, 'create_failed_request_messages_logs_file');

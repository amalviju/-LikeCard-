<?php

function create_like4card_general_logs_table()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_general_logs';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        `id` VARCHAR(40),
        `message` TEXT,
        `data` TEXT DEFAULT NULL,
        `date` DATETIME
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta($sql);

    file_log("creating '$table_name' table ...", [
        // 'sql' => $sql,
        'error' => $wpdb->last_error,
        'is_succeeded' => empty($wpdb->last_error)
    ]);
}

register_activation_hook(PLUGIN_FILE_PATH, 'create_like4card_general_logs_table');

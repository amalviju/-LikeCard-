<?php

function log_http_request_response($wp_http_response, $request, $url)
{
    if (strpos($url, 'https://taxes.like4app.com') === false)
        return $wp_http_response;

    $request = [
        'method' => $request['method'],
        'url' => $url,
        'headers' => $request['headers'],
        'body' => $request['body'],
    ];

    if ($wp_http_response instanceof WP_Error) {
        $response = [
            'errors' => $wp_http_response->errors,
            'error_data' => $wp_http_response->error_data,
        ];

        file_log("calling endpoint failed", [
            'url' => $url,
            'request' => $request,
            'response' => $response
        ]);
    } else {
        $response = [
            'status' => [
                'code' => wp_remote_retrieve_response_code($wp_http_response),
                'message' => wp_remote_retrieve_response_message($wp_http_response),
            ],
            'headers' => wp_remote_retrieve_headers($wp_http_response)->getAll(),
            'body' => wp_remote_retrieve_body($wp_http_response),
        ];
    }

    store_log_in_like4card_logs_table($request, $response, $url);

    return $wp_http_response;
}

add_filter('http_response', 'log_http_request_response', 10, 3);


function store_log_in_like4card_logs_table($request, $response, $url)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_logs';

    $datetime = date("Y-m-d H:i:s");

    $wpdb->insert($table_name, [
        'id' => uniqid(),
        "like4card_request" => json_encode($request),
        "like4card_response" => json_encode($response),
        "date" => $datetime,
        "url" => $url
    ]);
}

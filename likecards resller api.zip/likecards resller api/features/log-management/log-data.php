<?php

function db_log($message, $data = null)
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_general_logs';

    $datetime = date("Y-m-d H:i:s");

    $json = $data ? json_encode($data) : null;

    $wpdb->insert($table_name, [
        'id' => uniqid(),
        "message" => $message,
        "date" => $datetime,
        "data" => $json
    ]);
}

function file_log($message, $data = null)
{
    $json = $data ? json_encode($data) : null;

    $datetime = date("Y-m-d H:i:s");

    $error_message = $json ? "\n <br/> [$datetime] $message: $json <br/>" : "\n <br/> [$datetime] $message <br/>";

    $path = PLUGIN_DIR_PATH . '/errors.txt';
    $file = fopen($path, "a");

    fwrite($file, $error_message);

    fclose($file);
}

function failed_request_message_log($message, $data = null)
{
    $json = $data ? json_encode($data) : null;

    $datetime = date("Y-m-d H:i:s");

    $error_message = $json ? "\n <br/> [$datetime] $message: $json <br/>" : "\n <br/> [$datetime] $message <br/>";

    $path = PLUGIN_DIR_PATH . '/failed_requests_log.txt';
    $file = fopen($path, "a");

    fwrite($file, $error_message);

    fclose($file);
}
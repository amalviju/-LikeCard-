function downloadLogZipFile() {

    const formData = new FormData();
    formData.append('action', 'create_zip')

    const url = ajax_obj.admin_ajax_url;

    fetch(url, {
        method: 'POST',
        body: formData
    })
        .then(res => res.blob())
        .then(blob => {
            const file = window.URL.createObjectURL(blob);
            window.location.assign(file);
        });
}
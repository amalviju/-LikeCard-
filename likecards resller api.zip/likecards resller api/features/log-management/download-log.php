<?php

function get_requests_logs()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'like4card_logs';

    $query = "SELECT *
    FROM $table_name
    ORDER BY `date` ASC";

    $logs = $wpdb->get_results($query);

    return $logs;
}

function download_file($path)
{
    // $response = new WP_REST_Response;

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $path);

    $file_name = basename($path);

    // tell the browser what it's about to receive
    header("Content-Disposition: attachment; filename=$file_name;");
    header("Content-Type: $mime_type");
    header("Content-Description: File Transfer");
    header("Content-Transfer-Encoding: binary");
    header('Content-Length: ' . filesize($path));
    header("Cache-Control: no-cache private");

    // stream the file without loading it into RAM completely
    $fp = fopen($path, 'rb');
    fpassthru($fp);

    // kill WP
    exit;

    // $response->set_data(file_get_contents($path));
    // $response->set_headers([
    //     'Content-Type'   => "text/plain",
    //     'Content-Length' => filesize($path),
    // ]);

    // // HERE → This filter will return our binary image!
    // add_filter('rest_pre_serve_request', 'my_do_serve_image', 0, 2);

    // return $response;
}

function my_do_serve_image($served, $result)
{
    $image_data = null;

    // Check the "Content-Type" header to confirm that we really want to return
    // binary image data.
    foreach ($result->get_headers() as $header => $value) {
        if ('content-type' === strtolower($header)) {
            $image_data = $result->get_data();
            break;
        }
    }

    // Output the binary data and tell the REST server to not send any other
    // details (via "return true").
    if (is_string($image_data)) {
        echo $image_data;

        return true;
    }

    return $served;
}

function create_zip()
{
    $zip_file_path = PLUGIN_DIR_PATH . '/log.zip';

    if (file_exists($zip_file_path)) {

        unlink($zip_file_path);
    }

    $zip = new ZipArchive;
    $zip->open($zip_file_path, ZipArchive::CREATE);

    $errors_logs_file_path = PLUGIN_DIR_PATH . '/errors.txt';
    $failed_requests_log_file_path = PLUGIN_DIR_PATH . '/failed_requests_log.txt';

    $zip->addFromString(basename($errors_logs_file_path),  file_get_contents($errors_logs_file_path));
    $zip->addFromString(basename($failed_requests_log_file_path),  file_get_contents($failed_requests_log_file_path));

    $general_logs_temp_file = PLUGIN_DIR_PATH . '/general_logs.txt';

    if (file_exists($general_logs_temp_file)) {

        unlink($general_logs_temp_file);
    }

    $general_logs = get_requests_logs();


    $file = fopen($general_logs_temp_file, "a");


    foreach ($general_logs as $index => $log_entry) {

        $entry = "[$index] [{$log_entry->date}] [{$log_entry->url}] [{$log_entry->like4card_request}] [{$log_entry->like4card_response}]. \n\n\n";

        fwrite($file, $entry);
    }

    fclose($file);

    $zip->addFromString(basename($general_logs_temp_file), file_get_contents($general_logs_temp_file));

    $zip->close();

    unlink($general_logs_temp_file);

    return download_file($zip_file_path);
}

add_action('wp_ajax_create_zip', 'create_zip');
add_action('wp_ajax_nopriv_create_zip', 'create_zip');

<?php

function when_category_changed()
{
  $category_id = isset($_POST['category_id']) ? $_POST['category_id'] : null;
  $category_name = isset($_POST['category_name']) ? $_POST['category_name'] : null;

  $products = like4card_fetch_products($category_id);

  // $products = json_decode(stripslashes($products));

  if (!$products) {
    echo '<span class="no-product-found"> No products available. </span>';

    wp_die();
  }

  if ($products->response == 0) {
    echo '<span class="no-product-found"> No products available. </span>';

    wp_die();
  }

  show_products($products->data, $category_name);

  echo '';

  wp_die();
}

add_action('wp_ajax_when_category_changed', 'when_category_changed');
add_action('wp_ajax_nopriv_when_category_changed', 'when_category_changed');

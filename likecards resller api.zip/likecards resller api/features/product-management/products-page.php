<?php

function displayCategories($categories, $indentation = '')
{
    foreach ($categories as $category) {

        if (!empty($category->childs)) {
            displayCategories($category->childs, $indentation . '    ');
            continue;
        }

        $categoryId = $category->id;
        $categoryName = $category->categoryName;
        echo "$indentation <option value='$categoryId' data-category-name='$categoryName'> $categoryName </option>";
    }
}

$categories = like4card_fetch_categories();


if (!$categories) {
    echo 'No product was found.';
    return;
}

if ($categories->response == 0) {
    echo 'No product was found.';
    // failed_request_message_log($categories->message);
    return;
}

// Set default category ID
$defaultCategoryId = $categories->data[0]->id;2
?>
<div class="like4card-products-container">
    <div class="like4card-category-filter">
        <label for="like4card-category-select">Filter by Category:</label>
        <select id="like4card-category-select" onchange="onCategoryChanged(event)">
            <option value="">All Categories</option>
            <?php displayCategories($categories->data); ?>
        </select>
    </div>

    <div class="like4card-products">
        <div class="loader-container" style="display:none;">
            <div class="loader"></div>
        </div>

        <div class="like4card-product-list">
            <?php

            $defaultCategory = $categories->data[0];
            $defaultCategoryId = $defaultCategory->id;

            $response = like4card_fetch_products($defaultCategoryId);

            if (!$response) echo '<div class="no-product-found"> No products available. </div>';

            else if ($response->response == 0) echo '<div class="no-product-found"> No products available. </div>';

            else  show_products($response->data, $defaultCategory->categoryName);
            ?>
        </div>
    </div>

</div>
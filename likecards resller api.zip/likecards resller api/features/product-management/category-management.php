<?php

function like4card_fetch_categories()
{
    return sent_form_data_request('https://taxes.like4app.com/online/categories',  [
        'deviceId' => get_option('like4card_device_id'),
        'securityCode' => get_option('like4card_security_code'),
        'email' => get_option('like4card_email'),
        'password' => get_option('like4card_password'),
        'langId' => '1'
    ]);
}

function save_category($category_name)
{
    $taxonomy = 'product_cat'; // Use 'product_cat' for product categories in WooCommerce

    // Check if the category already exists
    $category_id = term_exists($category_name, $taxonomy);

    if ($category_id) return intval($category_id['term_id']);

    // Category doesn't exist, create it
    $category = wp_insert_term($category_name, $taxonomy);

    return intval($category['term_id']);
}

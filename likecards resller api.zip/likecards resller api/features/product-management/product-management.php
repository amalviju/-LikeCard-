<?php

function save_product()
{
    global $wpdb;

    $product = isset($_POST['product']) ? json_decode(stripslashes($_POST['product'])) : null;

    $wpdb->query('START TRANSACTION');

    $category_id = save_category($product->categoryName);

    if (!$category_id) {

        $wpdb->query('ROLLBACK');

        return wp_send_json([
            'errors' => [
                'invalid category',
            ]
        ]);

        echo '';

        wp_die();
    }

    // Create a new product object
    $wc_product = new WC_Product();

    // Set the product title
    $wc_product->set_name(trim($product->productName));

    // Set the product status to 'publish'
    $wc_product->set_status('publish');

    // Set the product regular price
    $wc_product->set_regular_price($product->sellPrice);

    // Set the product sale price
    $wc_product->set_sale_price($product->sellPrice);

    // Set the product virtual attribute
    $wc_product->set_virtual(true);

    // Set the product stock status
    $wc_product->set_stock_status($product->available ? 'instock' : 'outofstock');

    // Set the 'like4card_product_id' meta value
    $wc_product->add_meta_data('like4card_product_id', $product->id);

    // Set the '_cost' meta value
    $wc_product->update_meta_data('_cost', $product->productPrice);

    // Save the product
    $product_id = $wc_product->save();

    db_log("product saved successfully", [
        'product_id' => $product_id
    ]);

    $stored_like4card_product_id = check_if_has_like4card_product_id_meta($product_id);

    db_log("stored like4card product id", [
        'like4card_product_id' => $stored_like4card_product_id
    ]);

    $attaching_category_to_product_result = wp_set_object_terms($product_id, $category_id, 'product_cat');

    if ($attaching_category_to_product_result instanceof WP_Error) {

        $wpdb->query('ROLLBACK');

        db_log("we failed to attach product [$product_id] with category [$category_id]", [
            'exception' => $attaching_category_to_product_result
        ]);

        return wp_send_json([
            'errors' => $attaching_category_to_product_result->get_error_messages()
        ]);

        echo '';

        wp_die();
    }

    $setting_feature_image_from_external_url_result = set_featured_image_from_external_url($product->productImage, $product_id, $wpdb);

    if ($setting_feature_image_from_external_url_result instanceof WP_Error) {

        $wpdb->query('ROLLBACK');

        db_log("we failed to store product [$product_id]'s image", [
            'exception' => $attaching_category_to_product_result
        ]);

        return wp_send_json([
            'errors' => $setting_feature_image_from_external_url_result->get_error_messages()
        ]);

        echo '';

        wp_die();
    }

    $wpdb->query('COMMIT');

    file_log("[$product->productName] has been added successfully.");

    return wp_send_json([
        'status' => 'succeeded'
    ]);

    echo '';

    wp_die();
}

add_action('wp_ajax_save_product', 'save_product');
add_action('wp_ajax_nopriv_save_product', 'save_product');


function delete_product()
{
    $product_id = isset($_POST['product_id']) ? $_POST['product_id'] : null;

    $products = wc_get_products(array(
        'limit' => 1,
        'meta_query' => array(
            array(
                'key' => 'like4card_product_id',
                'value' => $product_id,
                'compare' => '='
            )
        )
    ));

    if (empty($products)) return;

    foreach ($products as $product) {

        $product->delete(true);
    }

    echo '';

    wp_die();
}

add_action('wp_ajax_delete_product', 'delete_product');
add_action('wp_ajax_nopriv_delete_product', 'delete_product');

function like4card_fetch_products($categoryId = '')
{
    $postData = array(
        'deviceId' => get_option('like4card_device_id'),
        'securityCode' => get_option('like4card_security_code'),
        'email' => get_option('like4card_email'),
        'password' => get_option('like4card_password'),
        'langId' => '1',
        // 'getTestProrduct' => 1
    );

    if (!empty($categoryId)) {
        $postData['categoryId'] = $categoryId;
    }

    $response = sent_form_data_request('https://taxes.like4app.com/online/products',  $postData);

    // set_transient('like4card_products_' . $categoryId, $response, 1800); // Save for 30 min

    return $response;
}

function fetch_products_by_ids($ids)
{
    $postData = array(
        'deviceId' => get_option('like4card_device_id'),
        'securityCode' => get_option('like4card_security_code'),
        'email' => get_option('like4card_email'),
        'password' => get_option('like4card_password'),
        'langId' => '1',
    );

    $postData += ids($ids);

    return sent_form_data_request('https://taxes.like4app.com/online/products', $postData);
}

function ids($ids)
{
    foreach ($ids as $key => $id) {
        $id_array["ids[$key]"] = $id;
    }

    return $id_array ?? [];
}

function get_like4card_products_that_merchant_has_in_his_database()
{
    global $wpdb;

    $posts_table =  $wpdb->prefix . 'posts';
    $postmeta_table =  $wpdb->prefix . 'postmeta';

    $query = "SELECT `$posts_table`.id, `$postmeta_table`.meta_value  as `like4card_product_id`
    FROM `$postmeta_table`
    INNER JOIN `$posts_table` 
             ON `$posts_table`.id = `$postmeta_table`.post_id
    WHERE `meta_key` = 'like4card_product_id'
    ORDER BY `post_id` DESC";

    $products = $wpdb->get_results($query);

    return $products;
}

function get_product_by_like4card_product_id($like4card_product_id)
{
    global $wpdb;

    $posts_table =  $wpdb->prefix . 'posts';
    $postmeta_table =  $wpdb->prefix . 'postmeta';

    $result = $wpdb->get_row("SELECT *
    FROM `$postmeta_table`
    INNER JOIN `$posts_table` 
             ON `$posts_table`.id = `$postmeta_table`.post_id
    WHERE `meta_key` = 'like4card_product_id' 
    AND `meta_value` = $like4card_product_id
    LIMIT 1; ");

    return $result;
}

function get_product_name_by_like4card_product_id($like4card_product_id)
{
    global $wpdb;

    $posts_table =  $wpdb->prefix . 'posts';
    $postmeta_table =  $wpdb->prefix . 'postmeta';

    $result = $wpdb->get_var("SELECT `post_title` as product_name
    FROM `$postmeta_table`
    INNER JOIN `$posts_table` 
             ON `$posts_table`.id = `$postmeta_table`.post_id
    WHERE `meta_key` = 'like4card_product_id' 
    AND `meta_value` = $like4card_product_id
    LIMIT 1; ");

    return $result;
}



function get_product_by_woocommerce_product_id($woocommerce_product_id)
{
    global $wpdb;

    $posts_table =  $wpdb->prefix . 'posts';

    $result = $wpdb->get_row("SELECT *
    FROM `$posts_table`
    WHERE `meta_value` = $woocommerce_product_id
    LIMIT 1; ");

    return $result;
}


function check_if_has_like4card_product_id_meta($woocommerce_product_id)
{
    global $wpdb;

    $posts_table =  $wpdb->prefix . 'posts';
    $postmeta_table =  $wpdb->prefix . 'postmeta';

    $query = "SELECT meta_value as like4card_product_id
    FROM `$postmeta_table`
    INNER JOIN `$posts_table` 
             ON `$posts_table`.id = `$postmeta_table`.post_id
    WHERE `meta_key` = 'like4card_product_id' 
    AND `$posts_table`.id = $woocommerce_product_id
    LIMIT 1; ";

    $result = $wpdb->get_var($query);

    return $result;
}


function get_stored_products($products)
{
    global $wpdb;

    $product_ids = implode(', ', array_column($products, 'productId'));

    $posts_table =  $wpdb->prefix . 'posts';
    $postmeta_table =  $wpdb->prefix . 'postmeta';

    $products = $wpdb->get_results("SELECT *
    FROM `$postmeta_table`
    INNER JOIN `$posts_table` 
             ON `$posts_table`.id = `$postmeta_table`.post_id
    WHERE `meta_key` = 'like4card_product_id' 
             AND meta_value in ($product_ids)
    ORDER BY `post_id` DESC");

    return $products;
}

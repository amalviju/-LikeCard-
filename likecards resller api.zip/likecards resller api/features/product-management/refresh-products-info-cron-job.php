<?php

// Register the cron job
function add_every_30_minutes_interval($schedules)
{
    $schedules['every_30_minutes'] = array(
        'interval' => 1800, // 30 minutes in seconds
        'display' => __('Every 30 Minutes'),
    );
    return $schedules;
}

add_filter('cron_schedules', 'add_every_30_minutes_interval');


//when plugin activated
function refresh_products_information_activation()
{
    if (!wp_next_scheduled('refresh_products_information')) {
        wp_schedule_event(time(), 'every_30_minutes', 'refresh_products_information');
    }
}

add_action('wp', 'refresh_products_information_activation');

// Unregister the cron job
// when plugin deactivated
function refresh_products_information_deactivation()
{
    wp_clear_scheduled_hook('refresh_products_information');
}


register_deactivation_hook(PLUGIN_FILE_PATH, 'refresh_products_information_deactivation');


// Define the cron job function
function refresh_products_information_function()
{
    $products_old_version = get_like4card_products_that_merchant_has_in_his_database();

    $fresh_version_of_like4card_products = get_products_by_like4card_product_ids($products_old_version);

    if (!$fresh_version_of_like4card_products) return;

    foreach ($products_old_version as $product_old_version) {

        $current_product_fresh_version = array_filter($fresh_version_of_like4card_products, function ($product) use ($product_old_version) {

            return $product->productId == $product_old_version->like4card_product_id;
        });

        if (empty($current_product_fresh_version)) {
            update_post_meta($product_old_version->id, '_stock_status', 'instock');
            continue;
        }

        $current_product_fresh_version = array_values($current_product_fresh_version);

        $current_product = $current_product_fresh_version[0];

        $newProductStatus = $current_product->available ? 'instock' : 'outofstock';

        update_post_meta($product_old_version->id, '_stock_status', $newProductStatus);
    }
}

add_action('refresh_products_information', 'refresh_products_information_function');

function get_products_by_like4card_product_ids($products)
{
    $product_ids = array_column($products, 'like4card_product_id');

    $response = fetch_products_by_ids($product_ids);

    if (!$response) return null;

    if ($response->response == 0) return null;

    // if ($response->errorCode) return null;

    return $response->data;
}


async function onCategoryChanged(e) {

    const selectedItem = e.target
    const categoryId = selectedItem.value;
    const categoryName = selectedItem.options[selectedItem.selectedIndex].getAttribute('data-category-name')

    console.log({
        id: categoryId,
        name: categoryName
    })

    const productsContainer = document.querySelector('.like4card-product-list');

    document.querySelector('.like4card-products>.loader-container').style.display = 'flex';
    productsContainer.classList.add('blurred-active');

    const getProductsByCategoryFormData = new FormData();
    getProductsByCategoryFormData.append('action', 'when_category_changed');
    getProductsByCategoryFormData.append('category_id', categoryId);
    getProductsByCategoryFormData.append('category_name', categoryName);

    const url = ajax_obj.admin_ajax_url;
    
    console.log(ajax_obj)

    const getProductsByCategoryResponse = await fetch(url, {
        method: 'POST',
        body: getProductsByCategoryFormData
    })

    document.querySelector('.like4card-products>.loader-container').style.display = 'none';
    productsContainer.classList.remove('blurred-active')

    productsContainer.innerHTML = await getProductsByCategoryResponse.text()
}

async function onAddToMyStoreButtonClick(e) {

    if (getSuggestedPrice(e.target.parentElement) >= getCost(e.target.parentElement)) {
        addToMyCart(e.target)
        return;
    }

    let areYouSure = confirm('Be careful! Suggested price is more than Cost, do you really want to add this product to your store?');

    if (!areYouSure) return;

    addToMyCart(e.target)
}

async function addToMyCart(addToMyCartButton) {
    const productsContainer = document.querySelector('.like4card-product-list');

    document.querySelector('.like4card-products>.loader-container').style.display = 'flex';
    productsContainer.classList.add('blurred-active');

    const saveProductResponse = await saveProduct(addToMyCartButton.parentElement)

    const saveProductAsJson = await saveProductResponse.json()

    document.querySelector('.like4card-products>.loader-container').style.display = 'none';
    productsContainer.classList.remove('blurred-active');

    if (!Object.hasOwn(saveProductAsJson, 'errors')) {

        addToMyCartButton.style.display = 'none';

        return;
    }

    let errors = '';

    saveProductAsJson.errors.forEach((error, index) => {

        errors += `${index + 1}-${error} \n`;
    });

    alert(errors);
}

function getSuggestedPrice(parentElement) {
    const sellPrice = parentElement.querySelector('.show-all-products-product-sell-price').value

    return Number.parseFloat(sellPrice)
}

function getCost(parentElement) {
    const cost = parentElement.querySelector('.show-all-products-product-price').value

    return Number.parseFloat(cost)
}

function saveProduct(parentElement) {

    const product = {
        id: parentElement.querySelector('.show-all-products-product-id').value,
        productImage: parentElement.querySelector('.show-all-products-product-image-url').value,
        productName: parentElement.querySelector('.show-all-products-product-name').innerHTML,
        available: parentElement.querySelector('.show-all-products-product-available').value,
        sellPrice: parentElement.querySelector('.show-all-products-product-sell-price').value,
        productPrice: parentElement.querySelector('.show-all-products-product-price').value,
        categoryName: parentElement.querySelector('.show-all-products-product-category').value
    }

    const formData = new FormData();
    formData.append('action', 'save_product')
    formData.append('product', JSON.stringify(product))

    const url = ajax_obj.admin_ajax_url;
    
    console.log(ajax_obj)

    return fetch(url, {
        method: 'POST',
        body: formData
    });
}

function deleteProduct(parentElement) {

    const formData = new FormData();
    formData.append('action', 'delete_product')
    formData.append('product_id', parentElement.querySelector('#show-all-products-product-id').value)

    const url = ajax_obj.admin_ajax_url;
    
    console.log(ajax_obj)

    fetch(url, {
        method: 'POST',
        body: formData
    });
}
<?php

function show_products($products, $category_name)
{

  $stored_products = get_stored_products($products);

  foreach ($products as $product) {

    $has_been_checked = has_been_checked_before($stored_products, $product->productId);

    $checked = $has_been_checked ? 'checked' : '';

    $imageUrl = $product->productImageWhiteLabel ?? $product->productImage;
?>

    <div class="like4card-product">


      <input class="show-all-products-product-id" hidden="hidden" type="number" value="<?= $product->productId ?>" />
      <input type="number" value="<?= $product->available ?>" class="show-all-products-product-available" hidden="hidden">
      <input type="text" value="<?= $product->productPrice ?>" class="show-all-products-product-price" hidden="hidden">
      <input type="text" value="<?= $product->sellPrice ?>" class="show-all-products-product-sell-price" hidden="hidden">
      <input type="text" value="<?= $category_name ?>" class="show-all-products-product-category" hidden="hidden">
      <input type="url" value="<?= $imageUrl  ?>" class="show-all-products-product-image-url" hidden="hidden">
      <img class="show-all-products-product-image" src="<?= $imageUrl ?>">
      <h2 class="show-all-products-product-name">' <?= $product->productName ?></h2>

      <?php
      echo $product->available ? '<div class="availability-label instock-label" > Available </div>' : '<div class="availability-label out-of-stock-label"> Out of Stock </div>';
      ?>

      <p><?= "Cost: $product->productPrice $product->productCurrency" ?></p>
      <p><?= "Suggested Price: $product->sellPrice $product->productCurrency" ?></p>

      <button onclick="onAddToMyStoreButtonClick(event)" class="wp-core-ui button wp-core-ui button-primary wp-core-ui button-secondary <?= $checked ? 'hidden' : '' ?>">Add to my store</button>
    </div>
<?php
  }
}

function has_been_checked_before($storedProducts, $currentProductId)
{
  $products = array_filter($storedProducts, function ($product) use ($currentProductId) {

    return $product->meta_value  == $currentProductId;
  });

  return !empty($products);
}

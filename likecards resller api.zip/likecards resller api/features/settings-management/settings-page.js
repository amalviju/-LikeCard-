function setAutoComplete(event) {

    document.getElementById('auto_complete').value = event.target.checked
}

function showSection(event, sectionId) {
    
    event.target.classList.add('selected-nav-item');

    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.add('hidden');
    });

    // Show the selected section
    const selectedSection = document.getElementById(sectionId);
    selectedSection?.classList?.remove('hidden');
}

async function refreshBalance(e) {

    const container = document.querySelector('.settings-page-content');

    document.querySelector('#settings-page > .loader-container').style.display = 'flex';
    container.classList.add('blurred-active');

    const formData = new FormData()
    formData.append('action', 'refresh_balance');

    const url = ajax_obj.admin_ajax_url;
    
    const response = await fetch(url, {
        method: 'POST',
        body: formData
    })

    const data = await response.json();

    if (data.response == 0) {
        document.querySelector('.heading-section')
            .insertAdjacentHTML('beforebegin', '<div class="notice notice-error is-dismissible"><p>an error occurred while refreshing your balance.</p></div>')

        document.querySelector('#settings-page > .loader-container').style.display = 'none';
        container.classList.remove('blurred-active')

        return;
    }

    e.target.parentElement.querySelector('.balance-info').innerHTML = `${data.balance} ${data.currency}`

    document.querySelector('.heading-section')
        .insertAdjacentHTML('beforebegin', '<div class="notice notice-success is-dismissible"><p>everything is up-to-date.</p></div>')

    document.querySelector('#settings-page > .loader-container').style.display = 'none';
    container.classList.remove('blurred-active')
}
<?php

function do_ping_request($device_id, $security_code, $email, $password)
{
    $api_response = get_balance($device_id, $security_code, $email, $password);

    if (!$api_response) {

        file_log("Your IP needs to be whitelisted, please contact us.");

        AdminNotice::displayError("Your IP needs to be whitelisted, please contact us.");

        return;
    }

    if ($api_response->response == 0 && $api_response->errorMessage == 'loginUnsuccessful') {

        failed_request_message_log($api_response->message);

        AdminNotice::displayError("Your API configs are not valid, please check them before submitting again.");

        return;
    }

    if ($api_response->response == 0) {

        failed_request_message_log($api_response->message);

        AdminNotice::displayError($api_response->message);

        return;
    }

    file_log('You are ready to link your Website with LikeCard!');

    AdminNotice::displaySuccess('You are ready to link your Website with LikeCard!');
}

function get_balance($device_id, $security_code, $email, $password)
{
    return sent_form_data_request('https://taxes.like4app.com/online/check_balance/',  [
        'deviceId' => $device_id,
        'securityCode' => $security_code,
        'email' => $email,
        'password' => $password,
        'langId' => '1'
    ]);
}

function refresh_balance()
{
    $get_balance = get_balance(get_option('like4card_device_id'), get_option('like4card_security_code'), get_option('like4card_email'), get_option('like4card_password'));

    return wp_send_json($get_balance);
}


add_action('wp_ajax_refresh_balance', 'refresh_balance');

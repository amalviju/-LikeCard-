<?php

function validate_like4card_config($settings)
{
    $validatedSettings = [];

    if (!isset($settings['like4card_device_id']) || empty($_POST['like4card_device_id'])) {

        AdminNotice::displayError('Device ID field is required');
        return;
    }

    $validatedSettings['like4card_device_id'] = sanitize_text_field($_POST['like4card_device_id']);


    if (!isset($settings['like4card_phone_number']) || empty($_POST['like4card_phone_number'])) {

        AdminNotice::displayError('Phone Number field is required');
        return;
    }

    $validatedSettings['like4card_phone_number'] = sanitize_text_field($_POST['like4card_phone_number']);


    if (!isset($_POST['like4card_security_code'])  || empty($_POST['like4card_security_code'])) {

        AdminNotice::displayError('Security code field is required');
        return;
    }

    $validatedSettings['like4card_security_code'] = sanitize_text_field($_POST['like4card_security_code']);


    if (!isset($_POST['like4card_email']) || empty($_POST['like4card_email'])) {

        AdminNotice::displayError('Email field is required');
        return;
    }

    $validatedSettings['like4card_email'] = sanitize_email($_POST['like4card_email']);


    if (!isset($_POST['like4card_password']) || empty($_POST['like4card_password'])) {

        AdminNotice::displayError('Password field is required');
        return;
    }

    $validatedSettings['like4card_password'] = sanitize_text_field($_POST['like4card_password']);


    if (!isset($_POST['like4card_secret_key']) || empty($_POST['like4card_secret_key'])) {

        AdminNotice::displayError('Secret key field is required');
        return;
    }

    $validatedSettings['like4card_secret_key'] = sanitize_text_field($_POST['like4card_secret_key']);


    if (!isset($_POST['like4card_secret_vi']) || empty($_POST['like4card_secret_vi'])) {

        AdminNotice::displayError('Secret vi field is required');
        return;
    }

    $validatedSettings['like4card_secret_vi'] = sanitize_text_field($_POST['like4card_secret_vi']);


    if (!isset($_POST['like4card_hash_key']) || empty($_POST['like4card_hash_key'])) {

        AdminNotice::displayError('Hash key field is required');
        return;
    }

    $validatedSettings['like4card_hash_key'] = sanitize_text_field($_POST['like4card_hash_key']);


    return $validatedSettings;
}

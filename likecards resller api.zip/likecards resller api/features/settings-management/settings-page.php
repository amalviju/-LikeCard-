<?php

// Render the settings page
function like4card_settings_page()
{
    $balance_response = get_balance(get_option('like4card_device_id'), get_option('like4card_security_code'), get_option('like4card_email'), get_option('like4card_password'));

?>
    <div class="wrap" id="settings-page">

        <div class="loader-container" style="display:none;">
            <div class="loader"></div>
        </div>

        <div class="settings-page-content">

            <div class="heading-section">
                <h1>LikeCard Settings</h1>


                <div class="balance-section">

                    <?php
                    if (!$balance_response || $balance_response->response == 0) {
                        echo '';
                        failed_request_message_log($balance_response->message);
                    } else {
                        echo "
                        <button type='button' class='wp-core-ui button wp-core-ui button-primary wp-core-ui button-secondary health-check-button' onclick='refreshBalance(event)'>
                            Refresh
                        </button>
    
                        <div class='balance-info'>
                            $balance_response->balance $balance_response->currency
                        </div>
                        ";
                    }
                    ?>

                </div>
            </div>


            <div class="navbar">
                <a href="#section1" onclick="showSection(event, 'section1')">Configurations</a>
                <a href="#section2" onclick="showSection(event,'section2')">LikeCard Products</a>
                <a href="#section3" onclick="showSection(event,'section3')">Logs</a>
            </div>

            <div id="section1" class="section">

                <form method="post" action="options.php" id="settings-form">
                    <?php
                    settings_fields('like4card_settings');
                    do_settings_sections('like4card_settings');
                    wp_nonce_field('after_submitting_settings_form', 'after_submitting_settings_form_nonce');
                    ?> <table class="form-table">

                        <tr>
                            <th scope="row"><label for="like4card_email">Email</label></th>
                            <td><input type="email" id="like4card_email" name="like4card_email" value="<?= esc_attr(get_option('like4card_email')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_password">Password</label></th>
                            <td><input type="password" id="like4card_password" name="like4card_password" value="<?= esc_attr(get_option('like4card_password')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_phone_number">Phone Number</label></th>
                            <td><input type="text" id="like4card_phone_number" name="like4card_phone_number" value="<?= esc_attr(get_option('like4card_phone_number')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_device_id">Device ID</label></th>
                            <td><input type="text" id="like4card_device_id" name="like4card_device_id" value="<?= esc_attr(get_option('like4card_device_id')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_security_code">Security Code</label></th>
                            <td><input type="text" id="like4card_security_code" name="like4card_security_code" value="<?= esc_attr(get_option('like4card_security_code')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_secret_key">Secret Key</label></th>
                            <td><input type="password" id="like4card_secret_key" name="like4card_secret_key" value="<?= esc_attr(get_option('like4card_secret_key')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_secret_vi">Secret iv</label></th>
                            <td><input type="password" id="like4card_secret_vi" name="like4card_secret_vi" value="<?= esc_attr(get_option('like4card_secret_vi')); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="like4card_hash_key">Hash key</label></th>
                            <td><input type="password" id="like4card_hash_key" name="like4card_hash_key" value="<?= esc_attr(get_option('like4card_hash_key')); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="auto_complete">Auto Complete</label></th>
                            <td>
                                <input type="checkbox" id="auto_complete" name="like4card_auto_complete" onchange="setAutoComplete(event)" <?= get_option('like4card_auto_complete') ? 'checked' : '' ?>>
                                <p style="color:red">By activating this option, you will be fully responsible for any fraudulent activity.</p>
                            </td>
                        </tr>
                    </table>

                    <?php


                    submit_button('Save Changes', 'primary', 'submit', false);

                    settings_errors('like4card_settings');
                    ?>
                </form>
            </div>

            <div id="section2" class="section hidden">
                <?php

                require_once PRODUCT_MANAGEMENT_DIR_PATH . '/products-page.php';
                ?>
            </div>

            <div id="section3" class="section hidden">
                <?php

                require_once LOG_MANAGEMENT_DIR_PATH . '/show-log.php';
                ?>
            </div>


        </div>


    </div>
<?php
}

function like4card_add_menu_page()
{
    add_menu_page(
        'Like4Card Settings',
        'Like4Card',
        'manage_options',
        'like4card_settings',
        'like4card_settings_page'
    );
}

// Add a new tab to the WordPress admin panel
add_action('admin_menu', 'like4card_add_menu_page');


function like4card_register_settings_fields()
{
    register_setting('like4card_settings', 'like4card_device_id');
    register_setting('like4card_settings', 'like4card_security_code');
    register_setting('like4card_settings', 'like4card_email');
    register_setting('like4card_settings', 'like4card_password');
    register_setting('like4card_settings', 'like4card_auto_complete');
    register_setting('like4card_settings', 'like4card_secret_key');
    register_setting('like4card_settings', 'like4card_secret_vi');
    register_setting('like4card_settings', 'like4card_phone_number');
    register_setting('like4card_settings', 'like4card_hash_key');
}

add_action('admin_init', 'like4card_register_settings_fields');


function like4card_add_settings_page()
{
    add_options_page('Like4Card Settings', 'Like4Card', 'manage_options', 'like4card-settings', 'like4card_settings_page');
}

add_action('admin_menu', 'like4card_add_settings_page');

function after_submitting_settings_form()
{
    if (!isset($_POST['after_submitting_settings_form_nonce'])) return;

    $wpnonce = $_POST['after_submitting_settings_form_nonce'];

    $is_secure = wp_verify_nonce($wpnonce, 'after_submitting_settings_form');

    if (!$is_secure) return;

    $validated_date = validate_like4card_config($_POST);

    if (!$validated_date) return;

    do_ping_request($validated_date['like4card_device_id'], $validated_date['like4card_security_code'], $validated_date['like4card_email'], $validated_date['like4card_password']);
}

add_action('admin_init', 'after_submitting_settings_form');

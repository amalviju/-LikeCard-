<?php

function sent_form_data_request($url, $body)
{
    $boundary = wp_generate_password(24);
    $headers  = [
        'content-type' => 'multipart/form-data; boundary=' . $boundary,
    ];

    $payload = '';

    foreach ($body as $name => $value) {
        $payload .= '--' . $boundary;
        $payload .= "\r\n";
        $payload .= 'Content-Disposition: form-data; name="' . $name .
            '"' . "\r\n\r\n";
        $payload .= $value;
        $payload .= "\r\n";
    }

    $payload .= '--' . $boundary . '--';

    $response = wp_remote_post($url, [
        'method' => 'POST',
        'headers' => $headers,
        'body' => $payload
    ]);

    return json_decode(wp_remote_retrieve_body($response));
}

function send_get_request($url)
{
    $response = wp_remote_get($url);

    $json = json_decode(wp_remote_retrieve_body($response));

    return $json;
}
